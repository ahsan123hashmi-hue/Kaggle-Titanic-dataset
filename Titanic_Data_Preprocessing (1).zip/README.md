# Titanic Data Cleaning and Preprocessing
Run the notebook with Kaggle Titanic train.csv in the same folder.